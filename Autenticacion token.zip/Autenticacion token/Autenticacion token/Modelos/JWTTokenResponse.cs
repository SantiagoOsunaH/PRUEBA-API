﻿namespace Autenticacion_token.Modelos
{
    public class JWTTokenResponse
    {
        public string? token{
            get;
            set;
        }
    }
}
